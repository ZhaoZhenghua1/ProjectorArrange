#pragma once
#include <QUndoCommand>

class AddLineCommand : public QUndoCommand
{

};

class AddSelectCommand : public QUndoCommand
{

};

class MoveCommand : public QUndoCommand
{

};

