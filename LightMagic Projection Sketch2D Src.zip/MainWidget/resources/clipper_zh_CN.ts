<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>BarDialog</name>
    <message>
        <location filename="BarSet.ui" line="14"/>
        <source>参考线设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BarSet.ui" line="31"/>
        <source>V:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BarSet.ui" line="57"/>
        <source>% 值:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BarSet.ui" line="64"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="ratio.ui" line="14"/>
        <source>项目分辨率</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ratio.ui" line="30"/>
        <source>项目分辨率:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ratio.ui" line="56"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWidget</name>
    <message>
        <location filename="MainWidget.cpp" line="94"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="97"/>
        <source>&amp;New</source>
        <translation type="unfinished">新建</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="101"/>
        <source>&amp;Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="105"/>
        <source>&amp;Save</source>
        <translation type="unfinished">保存</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="109"/>
        <source>Recent Files</source>
        <translation type="unfinished">最近打开的文件</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="112"/>
        <source>Project Ratio</source>
        <translation type="unfinished">项目分辨率</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="114"/>
        <source>Reference Map</source>
        <translation type="unfinished">参考图片</translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="185"/>
        <source>Open Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="227"/>
        <source>Open project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="254"/>
        <source>New project</source>
        <translation type="unfinished">新建工程 </translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="363"/>
        <source>Save changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="363"/>
        <source>Save changes to &apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWidget.cpp" line="363"/>
        <source>&apos; before closing?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectAreaDialog</name>
    <message>
        <location filename="SelectRectSet.ui" line="14"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="39"/>
        <source>编号:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="72"/>
        <source>Left:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="110"/>
        <location filename="SelectRectSet.ui" line="184"/>
        <location filename="SelectRectSet.ui" line="258"/>
        <location filename="SelectRectSet.ui" line="332"/>
        <source>%  值:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="123"/>
        <location filename="SelectRectSet.ui" line="197"/>
        <location filename="SelectRectSet.ui" line="271"/>
        <location filename="SelectRectSet.ui" line="345"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="146"/>
        <source>Right:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="220"/>
        <source>Top:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="SelectRectSet.ui" line="294"/>
        <source>Bottom:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransCoder</name>
    <message>
        <location filename="TransCoder.ui" line="20"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="37"/>
        <source>Input:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="50"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="61"/>
        <source>Framerate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="82"/>
        <source>External Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="92"/>
        <source>Overwrite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="106"/>
        <source>Start:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="125"/>
        <location filename="TransCoder.ui" line="164"/>
        <source>hh:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="145"/>
        <source>End:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="175"/>
        <source>Threads:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="208"/>
        <source>Video Codec:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="227"/>
        <source>copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="232"/>
        <source>aac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="237"/>
        <source>opus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="249"/>
        <source>Pixel Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="263"/>
        <source>yuv420p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="268"/>
        <source>yuv422p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="273"/>
        <source>yuv444p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="285"/>
        <source>Preset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="306"/>
        <source>I-Frame Interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="346"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;SimSun&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;msg&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoder.ui" line="393"/>
        <source>Transcode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TransCoderTab</name>
    <message>
        <location filename="TransCoderTab.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="28"/>
        <source>Output File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="42"/>
        <source>Left:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="81"/>
        <source>Right:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="120"/>
        <source>Top:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="159"/>
        <source>Bottom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="189"/>
        <source>Bitrate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TransCoderTab.ui" line="215"/>
        <source>mbps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
